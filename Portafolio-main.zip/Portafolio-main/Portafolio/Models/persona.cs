﻿namespace Portafolio.Models
{
    public class persona
    {
        public string Nombre { get; set; }
        public int Edad { get; set; }
    }
}
