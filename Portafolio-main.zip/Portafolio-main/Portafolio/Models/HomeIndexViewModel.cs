﻿namespace Portafolio.Models
{
    public class HomeIndexViewModel
    {
        public IEnumerable<ProyectoDIO> Proyectos { get; set; }
    }
}
